import streamlit as st
import pandas as pd
from datetime import datetime
import sys
import os
import base64


# Import from your notebook (converted to .py)
from analytics_module import (
    UtilizationAnalyticsEngine,
    VALID_GROUPBY_COLUMNS
)

def format_response(result: dict) -> dict:
    """Format the engine result into structured response for display"""
    
    formatted = {
        "narrative": "",
        "tables": {},
        "metrics": {},
        "insights": [],
        "recommendations": []
    }
    
    # Handle error
    if "error" in result:
        formatted["error"] = result["error"]
        return formatted
    
    # Extract narrative
    if "narrative_summary" in result:
        formatted["narrative"] = result["narrative_summary"]
    
    intent = result.get("query_intent", "")
    
    # Format based on intent type
    if intent == "edl_analysis":
        formatted = format_edl_analysis(result, formatted)
    elif intent == "target_achievement":
        formatted = format_target_achievement(result, formatted)
    elif intent == "resource_optimization":
        formatted = format_resource_optimization(result, formatted)
    elif intent == "unbilled_analysis":
        formatted = format_unbilled_analysis(result, formatted)
    elif intent == "buffer_analysis":
        formatted = format_buffer_analysis(result, formatted)
    elif intent == "diagnostic_analysis":
        formatted = format_diagnostic_analysis(result, formatted)
    elif intent == "nbl_threshold_analysis":
        formatted = format_nbl_threshold(result, formatted)
    elif intent == "comparative_analysis":
        formatted = format_comparative_analysis(result, formatted)
    elif intent == "project_distribution":
        formatted = format_project_distribution(result, formatted)
    elif intent == "location_breakdown":
        formatted = format_location_breakdown(result, formatted)
    elif intent == "tl_impact_analysis":
        formatted = format_tl_impact(result, formatted)
    else:
        # Default metric fetch
        formatted = format_metric_fetch(result, formatted)
    
    return formatted

def format_edl_analysis(result: dict, formatted: dict) -> dict:
    """Format EDL analysis results"""
    
    # Check if it's all EDLs or single EDL
    if result.get('analysis_type') == 'all_edls_comparison':
        formatted["narrative"] = result.get("narrative_summary", "EDL Analysis Complete")
        
        # Complete metrics table
        if result.get('complete_metrics_table'):
            formatted["tables"]["EDL Metrics Overview"] = pd.DataFrame(result['complete_metrics_table'])
        
        # Comparison metrics
        if result.get('comparison_metrics'):
            comp = result['comparison_metrics']
            formatted["metrics"]["Average Utilization"] = f"{comp.get('average_utilization', 0):.1f}%"
            
            if comp.get('ranking'):
                top_edls = comp['ranking'][:5]
                formatted["tables"]["Top Performing EDLs"] = pd.DataFrame(top_edls)
    
    else:
        # Single EDL analysis
        if result.get('summary'):
            summary = result['summary']
            formatted["metrics"]["Overall Utilization"] = f"{summary.get('overall_utilization', 0)}%"
            formatted["metrics"]["Total FTE"] = f"{summary.get('total_fte', 0):.1f}"
            formatted["metrics"]["Total Projects"] = summary.get('total_projects', 0)
            formatted["metrics"]["Performance Tier"] = summary.get('performance_tier', 'Unknown')
        
        # Complete metrics table
        if result.get('complete_metrics_table'):
            formatted["tables"]["Portfolio Metrics"] = pd.DataFrame(result['complete_metrics_table'])
        
        # Key insights
        if result.get('key_insights'):
            formatted["insights"] = result['key_insights']
    
    return formatted

def format_target_achievement(result: dict, formatted: dict) -> dict:
    """Format target achievement analysis"""
    
    formatted["metrics"]["Current Utilization"] = f"{result.get('current_utilization', 0)}%"
    formatted["metrics"]["Target Utilization"] = f"{result.get('target_utilization', 0)}%"
    formatted["metrics"]["Gap (FTE)"] = f"{result.get('utilization_gap_fte', 0):.1f}"
    formatted["metrics"]["Optimizable NBL"] = f"{result.get('optimizable_nbl_fte', 0):.1f}"
    
    if result.get('top_projects'):
        formatted["tables"]["Top Projects for Improvement"] = pd.DataFrame(result['top_projects'])
    
    if result.get('target_achievable'):
        formatted["insights"].append("✅ Target is achievable with current optimizable resources")
    else:
        formatted["insights"].append("⚠️ Additional strategies needed to achieve target")
    
    return formatted

def format_resource_optimization(result: dict, formatted: dict) -> dict:
    """Format resource optimization results"""
    
    formatted["metrics"]["Current Utilization"] = f"{result.get('current_utilization', 0)}%"
    formatted["metrics"]["New Utilization"] = f"{result.get('new_utilization', 0)}%"
    formatted["metrics"]["Improvement"] = f"+{result.get('utilization_improvement', 0):.1f}%"
    formatted["metrics"]["Total Removed"] = f"{result.get('total_removed', 0)} FTE"
    
    if result.get('removal_plan'):
        formatted["tables"]["Removal Plan"] = pd.DataFrame(result['removal_plan'])
    
    if result.get('unbilled_breakdown'):
        formatted["tables"]["Unbilled Breakdown"] = pd.DataFrame(
            list(result['unbilled_breakdown'].items()),
            columns=['Category', 'FTE']
        )
    
    return formatted

def format_unbilled_analysis(result: dict, formatted: dict) -> dict:
    """Format unbilled analysis results"""
    
    formatted["metrics"]["Total Unbilled FTE"] = f"{result.get('total_unbilled_fte', 0):.1f}"
    formatted["metrics"]["Total Associates"] = result.get('total_unbilled_associates', 0)
    
    if result.get('strategic_breakdown'):
        strategic_df = pd.DataFrame([
            {
                "Category": k,
                "Unbilled FTE": v.get('Unbilled_FTE', 0),
                "Associate Count": v.get('associate_count', 0)
            }
            for k, v in result['strategic_breakdown'].items()
        ])
        formatted["tables"]["Strategic Breakdown"] = strategic_df
    
    if result.get('detailed_category_breakdown'):
        category_df = pd.DataFrame([
            {
                "Category": k,
                "Unbilled FTE": v.get('Unbilled_FTE', 0),
                "Associate Count": v.get('associate_count', 0)
            }
            for k, v in result['detailed_category_breakdown'].items()
        ])
        formatted["tables"]["Detailed Category Breakdown"] = category_df
    
    if result.get('msa_vs_non_msa'):
        msa_data = result['msa_vs_non_msa']
        formatted["metrics"]["MSA Buffer"] = f"{msa_data.get('msa_buffer_fte', 0):.1f} FTE"
        formatted["metrics"]["Non-MSA Buffer"] = f"{msa_data.get('non_msa_buffer_fte', 0):.1f} FTE"
    
    return formatted

def format_buffer_analysis(result: dict, formatted: dict) -> dict:
    """Format buffer analysis results"""
    
    formatted["metrics"]["MSA Buffer"] = f"{result.get('msa_buffer_fte', 0):.1f} FTE"
    formatted["metrics"]["Non-MSA Buffer"] = f"{result.get('non_msa_buffer_fte', 0):.1f} FTE"
    formatted["metrics"]["Total Movable"] = f"{result.get('total_movable_fte', 0):.1f} FTE"
    formatted["metrics"]["Optimization Opportunity"] = f"{result.get('optimization_opportunity', 0):.1f} FTE"
    
    if result.get('detailed_breakdown', {}).get('category_breakdown'):
        category_df = pd.DataFrame([
            {
                "Category": k,
                "Unbilled FTE": v.get('Unbilled_FTE', 0),
                "Associate Count": v.get('associate_count', 0)
            }
            for k, v in result['detailed_breakdown']['category_breakdown'].items()
        ])
        formatted["tables"]["Buffer Category Breakdown"] = category_df
    
    return formatted

def format_diagnostic_analysis(result: dict, formatted: dict) -> dict:
    """Format diagnostic analysis results"""
    
    formatted["metrics"]["Projects Analyzed"] = result.get('projects_analyzed', 0)
    formatted["metrics"]["Average Utilization"] = f"{result.get('average_utilization', 0)}%"
    
    if result.get('insights'):
        formatted["insights"] = result['insights'][:5]
    
    if result.get('recommendations'):
        formatted["recommendations"] = result['recommendations'][:5]
    
    return formatted

def format_nbl_threshold(result: dict, formatted: dict) -> dict:
    """Format NBL threshold analysis"""
    
    formatted["metrics"]["Threshold"] = f"{result.get('threshold', 0)}%"
    formatted["metrics"]["Projects Above Threshold"] = result.get('projects_above_threshold', 0)
    formatted["metrics"]["High NBL FTE"] = f"{result.get('total_high_nbl_fte', 0):.1f}"
    formatted["metrics"]["Share of Portfolio"] = f"{result.get('high_nbl_share_%', 0):.1f}%"
    
    if result.get('high_nbl_projects'):
        formatted["tables"]["High NBL Projects"] = pd.DataFrame(result['high_nbl_projects'])
    
    if result.get('recommendations'):
        formatted["recommendations"] = result['recommendations']
    
    return formatted

def format_comparative_analysis(result: dict, formatted: dict) -> dict:
    """Format comparative analysis results"""
    
    if result.get('comparison_data'):
        formatted["tables"]["EDL Comparison"] = pd.DataFrame(result['comparison_data'])
    
    return formatted

def format_project_distribution(result: dict, formatted: dict) -> dict:
    """Format project distribution analysis"""
    
    formatted["metrics"]["Total Projects"] = result.get('total_projects', 0)
    formatted["metrics"]["Total FTE"] = f"{result.get('total_fte', 0):.1f}"
    
    if result.get('project_distribution'):
        dist_df = pd.DataFrame([
            {
                "Project": k,
                **v
            }
            for k, v in result['project_distribution'].items()
        ])
        formatted["tables"]["Project Distribution"] = dist_df
    
    if result.get('concentration_metrics'):
        conc = result['concentration_metrics']
        formatted["metrics"]["Top Project Share"] = f"{conc.get('top_project_share_%', 0):.1f}%"
    
    return formatted

def format_location_breakdown(result: dict, formatted: dict) -> dict:
    """Format location breakdown analysis"""
    
    formatted["metrics"]["Total Locations"] = result.get('total_locations', 0)
    
    if result.get('location_breakdown'):
        loc_df = pd.DataFrame([
            {
                "Location": k,
                **v
            }
            for k, v in result['location_breakdown'].items()
        ])
        formatted["tables"]["Location Breakdown"] = loc_df
    
    if result.get('performance_metrics'):
        perf = result['performance_metrics']
        formatted["metrics"]["Utilization Std Dev"] = f"{perf.get('utilization_std', 0):.1f}%"
        formatted["metrics"]["Utilization Range"] = f"{perf.get('utilization_range', 0):.1f}%"
    
    return formatted

def format_tl_impact(result: dict, formatted: dict) -> dict:
    """Format TL impact analysis"""
    
    formatted["metrics"]["Total TL FTE"] = f"{result.get('total_tl_fte', 0):.1f}"
    formatted["metrics"]["TL Unbilled FTE"] = f"{result.get('total_tl_unbilled_fte', 0):.1f}"
    formatted["metrics"]["TL Unbilled Impact"] = f"{result.get('tl_unbilled_impact_%', 0):.1f}%"
    formatted["metrics"]["TL Share of Unbilled"] = f"{result.get('tl_share_of_unbilled_%', 0):.1f}%"
    
    if result.get('tl_unbilled_by_category'):
        cat_df = pd.DataFrame(
            list(result['tl_unbilled_by_category'].items()),
            columns=['Category', 'FTE']
        )
        formatted["tables"]["TL Unbilled by Category"] = cat_df
    
    if result.get('critical_insights'):
        formatted["insights"] = result['critical_insights']
    
    return formatted

def format_metric_fetch(result: dict, formatted: dict) -> dict:
    """Format default metric fetch results"""
    
    if result.get('metrics_summary'):
        summary = result['metrics_summary']
        formatted["metrics"]["Average Utilization"] = f"{summary.get('average_utilization', 0)}%"
        formatted["metrics"]["Average NBL"] = f"{summary.get('average_nbl', 0)}%"
        formatted["metrics"]["Total Groups"] = summary.get('total_groups', 0)
        
        if summary.get('top_performers'):
            formatted["tables"]["Top Performers"] = pd.DataFrame(summary['top_performers'])
        
        if summary.get('concern_areas'):
            formatted["tables"]["Areas of Concern"] = pd.DataFrame(summary['concern_areas'])
    
    if result.get('raw_metrics'):
        formatted["tables"]["Complete Metrics"] = pd.DataFrame(result['raw_metrics'])
    
    return formatted

def _display_metrics(metrics: dict):
    """Safely render the metric cards."""
    if not metrics:
        return

    n = len(metrics)
    if n == 0:
        return
    elif n == 1:
        name, value = next(iter(metrics.items()))
        st.metric(label=name, value=value)
    else:
        cols = st.columns(n)
        for col, (name, value) in zip(cols, metrics.items()):
            col.metric(label=name, value=value)

def get_base64_encoded_image(image_path):
    """Convert image to base64 for HTML display"""
    try:
        with open(image_path, "rb") as img_file:
            return base64.b64encode(img_file.read()).decode()
    except Exception:
        return None

# Page configuration
st.set_page_config(
    page_title="Util Agent",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for blue theme with Cognizant colors
st.markdown("""
<style>
    /* Main background - White theme */
    .stApp {
        background-color: #FFFFFF;
        color: #333333;
    }
    
    /* Sidebar styling */
    [data-testid="stSidebar"] {
        background-color: #F8F9FA;
        border-right: 1px solid #E0E0E0;
    }
    
    /* Header container for title and logo */
    .header-container {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 1rem;
    }
    
    /* Chat messages */
    div[data-testid="stChatMessage"]:has(> div[data-testid="chatAvatarIcon-user"]) {
        background-color: #F0F8FF;
        margin-left: 10%;
        padding: 1.5rem;
        border-radius: 0.5rem;
        margin-bottom: 1rem;
        border-left: 4px solid #4985CA;
    }
    
    div[data-testid="stChatMessage"]:has(> div[data-testid="chatAvatarIcon-assistant"]) {
        background-color: #FFFFFF;
        border: 1px solid #E0E0E0;
        padding: 1.5rem;
        border-radius: 0.5rem;
        margin-bottom: 1rem;
        border-left: 4px solid #2A788E;
    }
    
    /* Input box styling */
    div[data-testid="stChatInput"] input {
        border-radius: 24px;
        border: 1px solid #E0E0E0;
        padding: 12px 20px;
        background-color: #FFFFFF;
        color: #333333;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    
    /* Logo in header */
    .header-logo {
        height: 40px;
        margin-left: auto;
    }
    
    /* Table styling */
    .dataframe {
        font-size: 14px;
        border-collapse: collapse;
        width: 100%;
        margin: 1rem 0;
        background-color: #FFFFFF;
        color: #333333;
        border: 1px solid #E0E0E0;
    }
    
    .dataframe th {
        background-color: #000149;
        color: #FFFFFF;
        padding: 12px;
        text-align: left;
        font-weight: 600;
        border-bottom: 2px solid #000149;
    }
    
    .dataframe td {
        padding: 10px 12px;
        border-bottom: 1px solid #E0E0E0;
        color: #333333;
    }
    
    .dataframe tr:hover {
        background-color: #F8F9FA;
    }
    
    /* Metric containers */
    div[data-testid="metric-container"] {
        background-color: #FFFFFF;
        border: 1px solid #E0E0E0;
        border-radius: 8px;
        padding: 1rem;
        margin: 0.5rem 0;
        color: #333333;
        box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    }
    
    div[data-testid="metric-label"] {
        font-size: 14px;
        color: #666666;
        margin-bottom: 0.25rem;
    }
    
    div[data-testid="metric-value"] {
        font-size: 24px;
        font-weight: 600;
        color: #000149;
    }
    
    /* Expander styling */
    .streamlit-expanderHeader {
        color: #333333;
        background-color: #F8F9FA;
        border: 1px solid #E0E0E0;
        border-radius: 4px;
    }
    
    .streamlit-expanderContent {
        background-color: #FFFFFF;
        color: #333333;
        border: 1px solid #E0E0E0;
        border-top: none;
    }
    
    /* Buttons */
    .stButton button {
        background-color: #000149;
        color: #FFFFFF;
        border: none;
        border-radius: 4px;
        padding: 8px 16px;
        font-weight: 500;
    }
    
    .stButton button:hover {
        background-color: #2A788E;
        color: #FFFFFF;
    }
    
    /* History query buttons */
    .history-query {
        background-color: #FFFFFF;
        border: 1px solid #E0E0E0;
        border-radius: 8px;
        padding: 8px 12px;
        margin: 4px 0;
        cursor: pointer;
        transition: all 0.2s;
        color: #333333;
    }
    
    .history-query:hover {
        background-color: #4985CA;
        color: #FFFFFF;
        border-color: #4985CA;
    }
    
    /* Info boxes */
    .stAlert {
        background-color: #E8F4FD;
        color: #333333;
        border: 1px solid #B8D9F3;
        border-radius: 4px;
    }
    
    /* Titles and captions */
    h1, h2, h3, h4, h5, h6 {
        color: #333333;
    }
    
    h1 {
        color: #000149;
    }
    
    .stCaption {
        color: #666666;
    }
    
    /* Sidebar specific styles */
    .sidebar .sidebar-content {
        background-color: #F8F9FA;
    }
    
    /* Divider styling */
    hr {
        border-color: #E0E0E0;
        margin: 1.5rem 0;
    }
    
    /* Spinner color */
    .stSpinner > div {
        border-color: #000149 transparent transparent transparent;
    }
    
    /* Success/Error messages */
    .stSuccess {
        background-color: #E8F5E8;
        color: #2E7D32;
        border: 1px solid #C8E6C9;
    }
    
    .stError {
        background-color: #FFEBEE;
        color: #C62828;
        border: 1px solid #FFCDD2;
    }
    
    /* Chat input container */
    [data-testid="stChatInputContainer"] {
        background-color: #FFFFFF;
        padding: 1rem;
        border-top: 1px solid #E0E0E0;
    }
</style>
""", unsafe_allow_html=True)

# Initialize session state
if 'messages' not in st.session_state:
    st.session_state.messages = []

if 'engine' not in st.session_state:
    with st.spinner("Initializing Util Agent..."):
        API_KEY = "AIzaSyAaK6AM5aEa4LsNfC7h40YrPnLchgymqYs"
        DATA_PATHS = {
            'prism': "gs://basedataadmin/data_for_model/prism_df.csv",
            'subcon': "gs://basedataadmin/data_for_model/subcon_df.csv",
            'mapping': "gs://basedataadmin/data_for_model/project_mapping_df.csv",
            'forecast': "gs://basedataadmin/data_for_model/forecast_df.csv"
        }
        try:
            st.session_state.engine = UtilizationAnalyticsEngine(API_KEY, DATA_PATHS)
            st.session_state.initialized = True
        except Exception as e:
            st.error(f"Failed to initialize engine: {e}")
            st.session_state.initialized = False

# Sidebar with history
with st.sidebar:
    st.title("💬 Chat History")
    
    # Clear history button
    if st.button("🗑️ Clear History", use_container_width=True):
        st.session_state.messages = []
        st.rerun()
    
    st.divider()
    
    # Display clickable chat history in sidebar
    if st.session_state.messages:
        user_messages = [m for m in st.session_state.messages if m["role"] == "user"]
        for i, msg in enumerate(user_messages):
            with st.container():
                # Create a unique key for each history item
                history_key = f"history_{i}"
                
                # Use button for clickable history
                if st.button(
                    f"🧑 {msg['content'][:45]}..." if len(msg['content']) > 45 else f"🧑 {msg['content']}",
                    key=history_key,
                    use_container_width=True
                ):
                    # When clicked, set this as the current view
                    st.session_state.viewing_history = True
                    st.session_state.viewing_index = i
                    st.rerun()
                
                st.caption(msg.get("timestamp", ""))
    else:
        st.info("No chat history yet")
    
    st.divider()
    
    # Example queries
    st.subheader("📝 Fequently Asked Queries")
    examples = [
        "Give me utilization by all EDLs",
        "Analyze EDL Garrett",
        "Show me projects with NBL > 25%",
        "What's the TL unbilled impact on Google portfolio?",
        "Compare EDL Bharath vs EDL Pradeepan"
    ]
    
    for example in examples:
        if st.button(example, key=f"example_{example}", use_container_width=True):
            st.session_state.example_query = example
            st.rerun()

# Main chat interface with header containing title and logo
col1, col2 = st.columns([4, 1])
with col1:
    st.title("Util Agent 📊")
with col2:
    # Display Cognizant logo in the header
    logo_path = "cognizant_logo.png"
    if os.path.exists(logo_path):
        logo_base64 = get_base64_encoded_image(logo_path)
        if logo_base64:
            st.markdown(f"""
            <div style="display: flex; justify-content: flex-end; align-items: center; height: 100%;">
                <img src="data:image/png;base64,{logo_base64}" width="120" alt="Cognizant Logo">
            </div>
            """, unsafe_allow_html=True)

st.caption("Your intelligent utilization analytics assistant")

# Handle history viewing
if st.session_state.get('viewing_history', False):
    index = st.session_state.viewing_index
    user_messages = [m for m in st.session_state.messages if m["role"] == "user"]
    assistant_messages = [m for m in st.session_state.messages if m["role"] == "assistant"]
    
    if index < len(user_messages) and index < len(assistant_messages):
        # Display the selected conversation
        st.info(f"📜 Viewing history - Query {index + 1}")
        
        # User message
        with st.chat_message("user"):
            st.markdown(user_messages[index]["content"])
        
        # Assistant message
        with st.chat_message("assistant"):
            content = assistant_messages[index]["content"]
            if "narrative" in content and content["narrative"]:
                st.markdown(f"**{content['narrative']}**")
            if "metrics" in content and content["metrics"]:
                _display_metrics(content["metrics"])
            if "tables" in content and content["tables"]:
                for table_name, table_data in content["tables"].items():
                    st.subheader(table_name)
                    if isinstance(table_data, pd.DataFrame):
                        st.dataframe(table_data, use_container_width=True)
                    else:
                        st.dataframe(pd.DataFrame(table_data), use_container_width=True)
            if "insights" in content and content["insights"]:
                with st.expander("💡 Key Insights", expanded=True):
                    for insight in content["insights"]:
                        st.markdown(f"- {insight}")
            if "recommendations" in content and content["recommendations"]:
                with st.expander("🎯 Recommendations", expanded=True):
                    for rec in content["recommendations"]:
                        st.markdown(f"- {rec}")
            if "error" in content:
                st.error(content["error"])
        
        # Back to current chat button
        if st.button("← Back to Current Chat"):
            st.session_state.viewing_history = False
            st.rerun()
    
    else:
        st.error("History entry not found")
        st.session_state.viewing_history = False
        st.rerun()

else:
    # Normal chat display - show all messages
    for message in st.session_state.messages:
        with st.chat_message(message["role"]):
            if message["role"] == "user":
                st.markdown(message["content"])
            else:
                content = message["content"]
                if "narrative" in content and content["narrative"]:
                    st.markdown(f"**{content['narrative']}**")
                if "metrics" in content and content["metrics"]:
                    _display_metrics(content["metrics"])
                if "tables" in content and content["tables"]:
                    for table_name, table_data in content["tables"].items():
                        st.subheader(table_name)
                        if isinstance(table_data, pd.DataFrame):
                            st.dataframe(table_data, use_container_width=True)
                        else:
                            st.dataframe(pd.DataFrame(table_data), use_container_width=True)
                if "insights" in content and content["insights"]:
                    with st.expander("💡 Key Insights", expanded=True):
                        for insight in content["insights"]:
                            st.markdown(f"- {insight}")
                if "recommendations" in content and content["recommendations"]:
                    with st.expander("🎯 Recommendations", expanded=True):
                        for rec in content["recommendations"]:
                            st.markdown(f"- {rec}")
                if "error" in content:
                    st.error(content["error"])

# Chat input
if st.session_state.get('initialized', False):
    if 'example_query' in st.session_state:
        user_input = st.session_state.example_query
        del st.session_state.example_query
    else:
        user_input = st.chat_input("Ask me anything about utilization analytics...")
    
    if user_input:
        # Exit history view when new query is made
        if st.session_state.get('viewing_history', False):
            st.session_state.viewing_history = False
        
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        st.session_state.messages.append({
            "role": "user",
            "content": user_input,
            "timestamp": timestamp
        })
        
        with st.spinner("Analyzing..."):
            try:
                result = st.session_state.engine.process_query(user_input)
                formatted_response = format_response(result)
                st.session_state.messages.append({
                    "role": "assistant",
                    "content": formatted_response,
                    "timestamp": timestamp
                })
            except Exception as e:
                st.session_state.messages.append({
                    "role": "assistant",
                    "content": {"error": f"An error occurred: {str(e)}"},
                    "timestamp": timestamp
                })
        
        st.rerun()
else:
    st.error("❌ Failed to initialize Util Agent. Please check your data files and API key.")